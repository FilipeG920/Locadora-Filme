require "test_helper"

class CopiaFilmeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
