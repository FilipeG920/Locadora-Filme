class Genero < ApplicationRecord
	has_many :filmes
end
