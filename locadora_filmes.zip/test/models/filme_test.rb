require "test_helper"

class FilmeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
