A aplicação é uma locadora onde o cliente pode alugar um filme de diversos gêneros e tipos de mídias(DVD, Blu-Ray), essa aplicação será servida em um website.
